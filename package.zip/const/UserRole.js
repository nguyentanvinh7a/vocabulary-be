const USER_ROLES = [
    {
        name: 'Super Admin',
        code: 'super_admin',
    },
    {
        name: 'Admin',
        code: 'admin',
    },
    {
        name: 'User',
        code: 'user',
    }
]

module.exports = USER_ROLES;