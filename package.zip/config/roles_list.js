const ROLE_LIST = {
    "ADMIN": "Admin",
    "SUPER_ADMIN": "Super Admin",
    "USER": "User"
}

module.exports = ROLE_LIST;