module.exports = {
    url: "mongodb+srv://nguyentanvinh7a:01685698193@cluster0.ebrk4.mongodb.net/vocabulary?retryWrites=true&w=majority"
    //url: "mongodb://localhost:27017/vocabulary"
};