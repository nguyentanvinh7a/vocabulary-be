module.exports = {
    ...require('./create'),
    ...require('./list'),
    ...require('./get')
};