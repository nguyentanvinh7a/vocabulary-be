module.exports = {
    ...require('./verifyToken'),
    ...require('./verifyRoles'),
};