module.exports = {
    ...require('./create'),
    ...require('./list'),
    ...require('./update'),
    ...require('./length'),
    ...require('./delete')
};