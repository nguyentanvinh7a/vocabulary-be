const List = require('../../models/List');
const Vocabulary = require('../../models/Vocabulary');

exports.getByListId = async (req, res) => {
    try {
        const listId = req.params.listId;
        const { page = 1, limit = 10 } = req.query;

        if (!listId) {
            return res.status(400).json({ msg: 'List ID is required' });
        }

        const list = await List.findById(listId);

        if (!list) {
            return res.status(404).json({ msg: 'List not found' });
        }

        const vocabularies = await Vocabulary.find({ list })
            .sort({ createdAt: -1 })
            .populate({
                path: 'word'
            })
            .limit(limit * 1)
            .skip((page - 1) * limit)
            .exec();

        return res.json({ list, vocabularies });
    } catch (err) {
        console.log(err.message);
        res.status(500).send(err.message);
    }
};